

<?php $__env->startSection('title', 'Halaman Dashboard'); ?>
<?php $__env->startSection('header_title', 'Ground Check'); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <li class="breadcrumb-item"><a href="/GroundCheck">Ground Check</a></li>
    <li class="breadcrumb-item active">View</li>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <style>
        #map {
            height: 300px;
            width: 100%;
            border-radius: 8px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/viewerjs/1.11.6/viewer.min.css">

    <script src="https://cdnjs.cloudflare.com/ajax/libs/viewerjs/1.11.6/viewer.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/cropperjs/1.5.13/cropper.min.js"></script>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card card-primary">
                <div class="card-header">
                    <h3 class="card-title">Form Input Usaha</h3>
                </div>

                <form action="<?php echo e(route('GroundCheck.update', $GroundCheck->idsbr)); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="card-body">
                        
                        <div class="form-group">
                            <label for="nama_usaha">Nama Usaha</label>
                            <input type="text" name="nama_usaha" class="form-control" id="nama_usaha"
                                value="<?php echo e($GroundCheck->nama_usaha); ?>" readonly>
                        </div>

                        
                        <div class="form-group">
                            <label for="petugas">Petugas <span class="text-danger">*</span></label>
                            <select name="petugas_id"
                                class="form-control <?php $__errorArgs = ['petugas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> select2bs4" id="petugas"
                                style="width: 100%;">
                                <option value="">-- Pilih Petugas --</option>
                                <?php $__currentLoopData = $listPetugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>"
                                        <?php echo e(old('petugas_id', $GroundCheck->petugas_id) == $p->id ? 'selected' : ''); ?>>
                                        <?php echo e($p->nama); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['petugas_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <div class="form-group">
                            <label for="alamat">Alamat Lengkap</label>
                            <textarea name="alamat" class="form-control" rows="3" readonly><?php echo e($GroundCheck->alamat); ?></textarea>
                        </div>

                        
                        <div class="form-group">
                            <label>Lokasi (Geotag) <span class="text-danger">*</span></label>
                            <div class="row">
                                <div class="col-6 col-md-5 mb-2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Lat</span>
                                        </div>
                                        <input type="text" name="latitude" id="latitude"
                                            class="form-control <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('latitude', $GroundCheck->latitude != 0 ? $GroundCheck->latitude : '')); ?>"
                                            placeholder="Klik Deteksi..." readonly>
                                    </div>
                                </div>

                                <div class="col-6 col-md-5 mb-2">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text">Long</span>
                                        </div>
                                        <input type="text" name="longitude" id="longitude"
                                            class="form-control <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            value="<?php echo e(old('longitude', $GroundCheck->longitude != 0 ? $GroundCheck->longitude : '')); ?>"
                                            placeholder="Klik Deteksi..." readonly>
                                    </div>
                                </div>

                                <div class="col-12 col-md-2 mb-2">
                                    <button type="button" class="btn btn-success btn-block" onclick="getLocation()">
                                        <i class="fas fa-map-marker-alt"></i> Deteksi
                                    </button>
                                </div>
                            </div>
                            
                            <?php if($errors->has('latitude') || $errors->has('longitude')): ?>
                                <span class="text-danger small">Koordinat lokasi wajib dideteksi.</span>
                            <?php endif; ?>

                            <div id="map" style="height: 300px;" class="mt-2"></div>
                        </div>

                        
                        <div class="form-group">
                            <label>Dokumentasi Foto Usaha <span class="text-danger">*</span></label>

                            
                            <?php if($GroundCheck->foto_usaha): ?>
                                <div id="foto-lama-container" class="mb-2">
                                    
                                    <img src="<?php echo e(asset($GroundCheck->foto_usaha)); ?>" class="img-thumbnail"
                                        style="max-height: 150px;" alt="Foto Saat Ini"
                                        onerror="this.src='https://placehold.co/300x200?text=Foto+Tidak+Ditemukan'">

                                    <p class="small text-muted">Foto saat ini</p>
                                </div>
                            <?php endif; ?>

                            <div class="row">
                                <div class="col-6">
                                    <label class="btn btn-primary btn-block">
                                        <i class="fas fa-camera"></i> Ambil Foto
                                        <input type="file" id="input_kamera" accept="image/*" capture="camera"
                                            class="d-none" onchange="processImage(this)">
                                    </label>
                                </div>
                                <div class="col-6">
                                    <label class="btn btn-info btn-block">
                                        <i class="fas fa-images"></i> Dari Galeri
                                        <input type="file" id="input_galeri" accept="image/*" class="d-none"
                                            onchange="processImage(this)">
                                    </label>
                                </div>
                            </div>

                            <div class="mt-3">
                                
                                <div id="loading-process" class="d-none text-primary mb-2 text-center">
                                    <i class="fas fa-spinner fa-spin"></i> Memproses & Mengambil GPS...
                                </div>

                                
                                <div id="wrapper-editor" class="d-none mb-3">
                                    <div style="max-height: 400px; overflow: hidden; background: #000;" class="rounded">
                                        <img id="image-to-crop" style="max-width: 100%;">
                                    </div>
                                    <div class="text-center mt-2">
                                        <button type="button" class="btn btn-success btn-block"
                                            onclick="finalizeImage()">
                                            <i class="fas fa-check"></i> Potong & Beri Watermark
                                        </button>
                                    </div>
                                </div>

                                
                                <div id="wrapper-hasil" class="<?php echo e(old('foto_compressed') ? '' : 'd-none'); ?> text-center">
                                    <label class="d-block text-muted">Hasil Foto Baru:</label>
                                    <img id="final-preview" src="<?php echo e(old('foto_compressed')); ?>" class="img-thumbnail"
                                        style="max-height: 300px;">
                                    <div class="mt-2">
                                        <button type="button" class="btn btn-sm btn-danger" onclick="removeImage()">
                                            <i class="fas fa-trash"></i> Hapus & Foto Ulang
                                        </button>
                                    </div>
                                </div>

                                
                                <input type="hidden" name="foto_compressed" id="foto_compressed"
                                    value="<?php echo e(old('foto_compressed')); ?>">
                                <p id="size-info" class="text-muted small mt-2 text-center"></p>

                                <?php $__errorArgs = ['foto_compressed'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-danger small d-block mt-1"><?php echo e($message); ?></span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>

                    <div class="card-footer d-flex justify-content-end">
                        <a href="<?php echo e(route('GroundCheck.index')); ?>" class="btn btn-default mr-3">
                            Batal <i class="fas fa-times"></i>
                        </a>
                        <?php if(!$GroundCheck->latitude || !$GroundCheck->longitude || !$GroundCheck->foto_usaha): ?>
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save"></i> Simpan Perubahan
                            </button>
                        <?php else: ?>
                            <div class="alert alert-success">
                                <i class="fas fa-check-circle"></i> Data Ground Check sudah lengkap dan telah tersimpan.
                            </div>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
    
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script>
        // 1. Ambil data dari Database via Blade
        // Jika data 0 atau null, gunakan default Jakarta
        var dbLat = parseFloat("<?php echo e($GroundCheck->latitude); ?>") || -6.200000;
        var dbLng = parseFloat("<?php echo e($GroundCheck->longitude); ?>") || 106.816666;

        // Inisialisasi Koordinat & Konfigurasi
        var defaultLat = dbLat;
        var defaultLng = dbLng;
        var maxRadius = 500;
        var centerPoint = L.latLng(defaultLat, defaultLng);
        var radiusCircle = null;

        // 2. Inisialisasi Peta - SetView langsung ke koordinat DB
        // Gunakan zoom 18 jika sudah ada koordinat, zoom 13 jika masih default
        var initialZoom = (dbLat !== -6.200000) ? 18 : 13;
        var map = L.map('map').setView(centerPoint, initialZoom);

        // --- LAYER GOOGLE MAPS HYBRID ---
        var googleHybrid = L.tileLayer('https://{s}.google.com/vt/lyrs=y&x={x}&y={y}&z={z}', {
            maxZoom: 20,
            subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
            attribution: 'Google Maps Satellite'
        }).addTo(map);

        // 3. Tambah Marker di lokasi koordinat DB
        var marker = L.marker(centerPoint, {
            draggable: true
        }).addTo(map);

        // Fungsi menggambar visual radius 500m
        function drawRadius(latlng) {
            if (radiusCircle) {
                map.removeLayer(radiusCircle);
            }
            radiusCircle = L.circle(latlng, {
                radius: maxRadius,
                color: 'red',
                fillColor: '#f03',
                fillOpacity: 0.1,
                dashArray: '5, 10'
            }).addTo(map);
        }

        drawRadius(centerPoint);

        // LOGIKA PEMBATASAN RADIUS SAAT DIGESER
        marker.on('drag', function(e) {
            var currentPos = e.target.getLatLng();
            var distance = centerPoint.distanceTo(currentPos);

            if (distance > maxRadius) {
                var ratio = maxRadius / distance;
                var lat = (currentPos.lat - centerPoint.lat) * ratio + centerPoint.lat;
                var lng = (currentPos.lng - centerPoint.lng) * ratio + centerPoint.lng;
                marker.setLatLng([lat, lng]);
            }

            var finalPos = marker.getLatLng();
            document.getElementById('latitude').value = finalPos.lat.toFixed(8);
            document.getElementById('longitude').value = finalPos.lng.toFixed(8);
        });

        // Ambil lokasi otomatis dari browser (GPS)
        function getLocation() {
            if (navigator.geolocation) {
                var options = {
                    enableHighAccuracy: true,
                    timeout: 10000,
                    maximumAge: 0
                };

                const btn = event.currentTarget;
                const originalText = btn.innerHTML;
                btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Mencari Satelit...';
                btn.disabled = true;

                navigator.geolocation.getCurrentPosition(function(position) {
                    var lat = position.coords.latitude;
                    var lng = position.coords.longitude;

                    centerPoint = L.latLng(lat, lng);

                    document.getElementById('latitude').value = lat.toFixed(8);
                    document.getElementById('longitude').value = lng.toFixed(8);

                    marker.setLatLng(centerPoint);
                    map.setView(centerPoint, 18);

                    drawRadius(centerPoint);

                    btn.innerHTML = originalText;
                    btn.disabled = false;
                }, function(error) {
                    btn.innerHTML = originalText;
                    btn.disabled = false;
                    alert("Error: " + error.message);
                }, options);
            }
        }
    </script>
    
    <script>
        let cropper = null;
        let tempGPS = {
            lat: "-",
            lng: "-"
        };
        let sumberFoto = "";

        function processImage(input) {
            const file = input.files[0];
            if (!file) return;

            sumberFoto = input.id;
            const loading = document.getElementById('loading-process');

            // Sembunyikan hasil lama dan editor saat memilih file baru
            loading.classList.remove('d-none');
            document.getElementById('wrapper-hasil').classList.add('d-none');
            document.getElementById('wrapper-editor').classList.add('d-none');

            if (sumberFoto === 'input_kamera') {
                // Ambil GPS dengan timeout agar tidak macet
                navigator.geolocation.getCurrentPosition(
                    (position) => {
                        tempGPS.lat = position.coords.latitude.toFixed(7);
                        tempGPS.lng = position.coords.longitude.toFixed(7);
                        loading.classList.add('d-none');
                        openEditor(file);
                    },
                    (error) => {
                        console.warn("GPS Gagal:", error);
                        tempGPS.lat = "-";
                        tempGPS.lng = "-";
                        loading.classList.add('d-none');
                        openEditor(file);
                    }, {
                        enableHighAccuracy: true,
                        timeout: 5000
                    }
                );
            } else {
                loading.classList.add('d-none');
                openEditor(file);
            }
        }

        function openEditor(file) {
            const imgElement = document.getElementById('image-to-crop');
            const reader = new FileReader();
            reader.onload = function(e) {
                imgElement.src = e.target.result;
                document.getElementById('wrapper-editor').classList.remove('d-none');

                // Sembunyikan foto lama dari database agar fokus ke editor
                if (document.getElementById('foto-lama-container')) {
                    document.getElementById('foto-lama-container').classList.add('d-none');
                }

                if (cropper) cropper.destroy();
                cropper = new Cropper(imgElement, {
                    aspectRatio: 4 / 3,
                    viewMode: 1,
                    dragMode: 'move'
                });
            };
            reader.readAsDataURL(file);
        }

        function finalizeImage() {
            if (!cropper) return;

            const canvas = cropper.getCroppedCanvas({
                width: 1024
            });
            const ctx = canvas.getContext('2d');

            if (sumberFoto === 'input_kamera') {
                const height = canvas.height;
                // Watermark box
                ctx.fillStyle = "rgba(0, 0, 0, 0.6)";
                ctx.fillRect(0, height - 90, 450, 90);
                // Teks
                ctx.fillStyle = "#ffffff";
                ctx.font = "bold 24px Arial";
                ctx.fillText("KAMERA TERVERIFIKASI", 20, height - 55);
                ctx.font = "20px Monospace";
                ctx.fillText("LAT: " + tempGPS.lat + " | LNG: " + tempGPS.lng, 20, height - 20);
            }

            const dataUrl = canvas.toDataURL('image/jpeg', 0.8);
            document.getElementById('foto_compressed').value = dataUrl;
            document.getElementById('final-preview').src = dataUrl;

            document.getElementById('wrapper-editor').classList.add('d-none');
            document.getElementById('wrapper-hasil').classList.remove('d-none');

            const fileSizeStr = Math.round((dataUrl.length * 3 / 4) / 1024);
            document.getElementById('size-info').innerHTML = "Ukuran: " + fileSizeStr + " KB " +
                (sumberFoto === 'input_kamera' ? "(Geotagged)" : "");

            cropper.destroy();
            cropper = null;
        }

        function removeImage() {
            document.getElementById('wrapper-hasil').classList.add('d-none');
            document.getElementById('foto_compressed').value = "";
            document.getElementById('input_kamera').value = "";
            document.getElementById('input_galeri').value = "";
            document.getElementById('size-info').innerHTML = "";

            // Tampilkan kembali foto lama jika ada
            if (document.getElementById('foto-lama-container')) {
                document.getElementById('foto-lama-container').classList.remove('d-none');
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Program\Website\Web Programing\Laravel\Linggau\portalSE\resources\views/groundcheck/view.blade.php ENDPATH**/ ?>