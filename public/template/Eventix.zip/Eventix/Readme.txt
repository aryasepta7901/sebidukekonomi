Thanks for downloading this template!

Template Name: Eventix
Template URL: https://bootstrapmade.com/eventix-bootstrap-events-website-template/
Author: BootstrapMade.com
License: https://bootstrapmade.com/license/
